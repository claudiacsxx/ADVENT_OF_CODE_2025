#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Rango {
    unsigned long long inicio;
    unsigned long long fin;
};

unsigned long long convertir_a_numero(const string &s) {
    unsigned long long n = 0;
    for (char c : s) {
        if (c >= '0' && c <= '9') {
            n = n * 10 + (c - '0');
        }
    }
    return n;
}

vector<Rango> leer_rangos(ifstream &archivo) {
    vector<Rango> rangos;
    string linea;
    while (getline(archivo, linea) && linea != "") {
        size_t guion = linea.find('-');
        string s1 = linea.substr(0, guion);
        string s2 = linea.substr(guion + 1);
        unsigned long long a = convertir_a_numero(s1);
        unsigned long long b = convertir_a_numero(s2);
        rangos.push_back({a, b});
    }
    return rangos;
}

int main() {
    ifstream archivo("Input5.txt");

    vector<Rango> rangos = leer_rangos(archivo);

    sort(rangos.begin(), rangos.end(), [](Rango a, Rango b) {
        return a.inicio < b.inicio;
    });

    vector<Rango> rangos_unidos;
    for (auto &r : rangos) {
        if (rangos_unidos.empty() || r.inicio > rangos_unidos.back().fin + 1) {
            rangos_unidos.push_back(r);
        } else {
            if (r.fin > rangos_unidos.back().fin) {
                rangos_unidos.back().fin = r.fin;
            }
        }
    }

    unsigned long long total_frescos = 0;
    for (auto &r : rangos_unidos) {
        total_frescos += (r.fin - r.inicio + 1);
    }

    cout << "Cantidad total de IDs frescos: " << total_frescos << endl;
    return 0;
}
