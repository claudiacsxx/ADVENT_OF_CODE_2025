#include <iostream>
#include <string>
#include <cstring>
using namespace std;

const int MAXN = 100;
int M[MAXN][MAXN]; //creamos matriz de memoria

//queremos encntrar el máximo de 2 dígitos en el rango [inicio, fin]
int maximoRango(const string& str, int inicio, int fin) {
    if (inicio >= fin - 1) return 0; //necesitamos al menos 2 posiciones
    
    // comprobamos a ver si ya esta calculado
    if (M[inicio][fin] != -1) {
        return M[inicio][fin];
    }
    
    //calculamos el maximo en este rango
    int maxVal = 0;
    for(int i = inicio; i < fin; i++) { //hacemos dos bucles porque queremos dos maximos
        for(int j = i + 1; j < fin; j++) { //queremos el primer maximo y luego el segundo a partir de la posicion del primero, por eso este bucle empieza despues de donde se encontro el primer maximo
            int ini = str[i] - '0'; //el - '0' es porque está en string asi que restamos como codigo ASCII
            int sig = str[j] - '0';
            int num = ini*10 + sig; //el primer maximo es *10 porque queremos un numero de dos digitos
            maxVal = max(maxVal, num); //seguimos recursivamente encontrando el maximo
        }
    }
    
    M[inicio][fin] = maxVal;
    return M[inicio][fin]; //devolvemos resultado a traves de la memoria
}

int maximo(string str) {
    memset(M, -1, sizeof(M)); //una vez encontrado el maximo, ponemos la memoria a -1
    return maximoRango(str, 0, str.length()); //devolvemos el resultado del maximo
}

int main(){
    string bank;
    int total = 0;
    while(getline(cin, bank)){ //mientras haya input que leer
        int maxim = maximo(bank); //guardamos maximos
        total += maxim; //sumamos resultados
        cout << "Bank " << bank << ": max = " << maxim << endl; //mostramos cada linea y su maximo
    }
    cout << "\nTotal: " << total << endl; //mostramos resultado final
    return 0;
}