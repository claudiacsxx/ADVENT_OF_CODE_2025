#include <iostream>
#include <sstream>
#include <string>
using namespace std;
//uso long long en vez de int pq los numeros son tan grandes que como que "no caben" en int
bool invalido(long long num){
    string str = to_string(num);
    int size = str.length();
    //ahora en vez de dividir a la mitad y compararlas hay que ver si un patron tiene 1 o mas numeros de "longitud"
    //como minimo se tiene que repetir 2 veces, el tamaño maximo de un patron es la mitad de la longitud de la cadena
    //y el tamaño minimo del patron es de 1 digito
    for(int patronLong = 1; patronLong <= size/2; patronLong++){
        if(size % patronLong == 0){ //ver si la longitud del string se puede dividir entre la del patron
            string patron = str.substr(0, patronLong);
            if(patron[0] == '0') continue; //en plan si hay un "leading 0" que no pasa nada osea que lo ignore
            
            bool esPatron = true; //si el string entero esta hecho del patron
            for(int i = patronLong; i < size; i += patronLong){ //leer el string y ver si el patron se repite
                if(str.substr(i, patronLong) != patron){ //si lo que vamos comparando no se repite
                    esPatron = false; //no hay patron
                    break; //se acaba el codigo
                }
            }
            if(esPatron){
                return true; //hay patron, ID invalido
            }
        }
    }
    return false; //no hay patron
}

long long sumaInv(long long ini, long long fin){
    if(fin - ini < 100){ //si son cifras pequeñas solo hace falta dividirlo una vez
        long long suma = 0;
        for(long long i = ini; i <= fin; i++){ //vamos leyendo uno a uno 
            if(invalido(i)){ //si es invalido
                suma += i; //sumamos los valores
            }
        }
        return suma;
    }
    long long mitad = ini + (fin - ini)/2; //esto es si son numeros mas grandes y hay que hacer divide y venceras varias veces
    long long izq = sumaInv(ini, mitad);
    long long der = sumaInv(mitad + 1, fin);
    return izq + der; //devuelve la suma de las dos partes
}

int main(){
    string numeros; //la primera linea entera, "11-22, 95-115..."
    getline(cin, numeros); //leemos los numeros del input
    stringstream ss(numeros); //esto es para separar el input en comas
    string rango; //esto es el rango de numeros ya separado, en plan "11-22" por ejemplo
    long long total = 0;
    
    while(getline(ss, rango, ',')){ //esto es para separar los numeros del dash -
        int dash = rango.find('-'); 
        string inistr = rango.substr(0, dash); //separa el 11 de "11-22"
        string finstr = rango.substr(dash+1); //separa el 22 de "11-22"
        long long inicio = stoll(inistr); //pasa los numeros de string a long long
        long long final = stoll(finstr);
        long long suma = sumaInv(inicio, final); //sumamos los valores
        total += suma; //sumamos los resultados
        cout << "Rango " << rango << ": suma = " << suma << endl; //muestra en que rango hay suma y lo que se suma
    }
    cout << "\nTotal: " << total << endl; //resultado final
    return 0;
}