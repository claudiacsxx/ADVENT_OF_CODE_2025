#include <iostream>
#include <sstream>
#include <string>
using namespace std;
//uso long long en vez de int pq los numeros son tan grandes que como que "no caben" en int
bool invalido(long long num){
    string str = to_string(num); //al leer el input del texto lo leemos como numero asi que lo pasamos a string pa poder dividirlo
    int size = str.length(); 
    if(size % 2 != 0){ //un numero de cifras impares no puede ser igual al principio y al final
        return false;
    }
    else{
        string mitad1 = str.substr(0, size/2); //separamos por mitades 
        string mitad2 = str.substr(size/2);
        return(mitad1[0] != '0' && mitad1 == mitad2); //solo sera invalido si la primera mitad no esta vacia y si las dos mitades son iguales
    }
}

long long sumaInv(long long ini, long long fin){
    if(fin - ini < 100){ //si son cifras pequeñas solo hace falta dividirlo una vez
        long long suma = 0;
        for(long long i = ini; i <= fin; i++){
            if(invalido(i)){
                suma += i; //si son invalidos, vamos sumando sus valores
            }
        }
        return suma;
    }
    long long mitad = ini + (fin - ini)/2; //esto es si son numeros mas grandes y hay que hacer divide y venceras varias veces
    long long izq = sumaInv(ini, mitad); //sumamos por mitades
    long long der = sumaInv(mitad + 1, fin);
    return izq + der; //devolvemos la suma de ambas partes
}

int main(){
    string numeros; //la primera linea entera, "11-22, 95-115..."
    getline(cin, numeros);
    stringstream ss(numeros); //esto es para separar el input en comas
    string rango; //esto es el rango de numeros ya separado, en plan "11-22" por ejemplo
    long long total = 0;
    
    while(getline(ss, rango, ',')){ //esto es para separar los numeros del dash -
        int dash = rango.find('-');
        string inistr = rango.substr(0, dash); //separa el 11 de "11-22"
        string finstr = rango.substr(dash+1); //separa el 22 de "11-22"
        long long inicio = stoll(inistr); //pasamos las mitades de string a long long
        long long final = stoll(finstr); 
        long long suma = sumaInv(inicio, final);
        total += suma; //sumamos los resultados de las sumas 
        cout << "Rango " << rango << ": suma = " << suma << endl; //se ve en que rango hay suma y que se suma
    }
    cout << "\nTotal: " << total << endl; //resultado final   
    return 0;
}