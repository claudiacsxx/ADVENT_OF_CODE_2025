#include <iostream>
#include <string>
#include <cstring>
using namespace std;

const int MAXN = 100;
const int MAXD = 13;
string M[MAXN][MAXD]; //creamos matriz memoria M[posicion][digitos_restantes] para evitar calcular lo mismo muchas veces
bool calculado[MAXN][MAXD]; //para saber si ya se calculó

//queremos encontrar los maximos
string maxMem(const string& str, int inicio, int digitos) {
    //caso base: linea de 0s
    if (digitos == 0) {
        return "";
    }
    //caso base: string vacio (size>= 0)
    if (inicio >= str.length()) {
        return "";
    }
    
    //comprobamos si ya esta caluclado
    if (calculado[inicio][digitos]) {
        return M[inicio][digitos];
    }
    
    //buscamos el máximo (caracter) disponible, es decir, con minimo 11 digitos disponibles despues suya porque necesitamos 12 baterias
    char maxC = '0';
    int maxP = inicio; //posicion del maximo
    int fin = str.length() - digitos + 1; //formula para calcular los digitos que haya despues del maximo para asegurar que quedan minimo 11
    
    for(int j = inicio; j < fin; j++){ //bucle para encontrar el maximo y su posicion
        if(str[j] > maxC){
            maxC = str[j];
            maxP = j;
        }
    }
    
    //recursion con el resto de linea para encontrar los maximos
    string resultado = maxC + maxMem(str, maxP + 1, digitos - 1);
    
    //guardamos resultado en la memoria
    M[inicio][digitos] = resultado;
    calculado[inicio][digitos] = true;
    
    return M[inicio][digitos]; //devolvemos resultado
}

string max(string str){
    //inicializamos memoria a -1
    memset(calculado, false, sizeof(calculado));
    return maxMem(str, 0, 12); //devolvemos maximos calculados
}

int main(){
    string bank;
    long long total = 0;
    while(getline(cin, bank)){ //mientras haya input que leer
        string maxV = max(bank); //encontramos maximo
        long long suma = stoll(maxV); //pasamos maximos a long long
        total += suma; //sumamos resultados
        cout << "Bank " << bank << ": max = " << maxV << endl; //mostramos cada linea y su maximo
    }
    cout << "\nTotal: " << total << endl; //mostramos resultado final
    return 0;
}