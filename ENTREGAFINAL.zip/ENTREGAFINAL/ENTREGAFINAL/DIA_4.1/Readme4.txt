
\\POR QUÉ ELEGIMOS ESTE EJERCICIO\\
Este ejercicio se ha elegido porque permite trabajar con estructuras matriciales y recorridos en dos dimensiones, algo muy habitual en problemas algorítmicos.
La solución muestra cómo analizar el estado de cada elemento en función de sus vecinos, aplicando una lógica iterativa clara.
Además, se observa cómo un problema se resuelve por pasos recursivos hasta alcanzar una solucion.
El código ayuda a entender la importancia de controlar condiciones de parada y evitar errores en recorridos de matrices.

\\ EJERCICIO 1\\

-Primero llamamos matriz a la matriz de dos dimensiones y line al string que vamos a utilizar de forma auxiliar

-De seguido, en las lineas 12,13,14, hcaemos un bucle que lee el archivo linea por linea y que se lo añade a la matriz grid

-A continuación definimos n como el numero de filas y m como el de columnas; añadimos int result como contador para el numero de rollos accesible

-Se definen los vecinos de una celda:
    int dx[8] = {-1,-1,-1,0,0,1,1,1};
    int dy[8] = {-1,0,1,-1,1,-1,0,1};
    Y creamos un bulce for anidado para recorrer la matriz comodamente

-Creamos la condición  if (grid[i][j] == '@') ya que solamente nos interesan los @

-se define cnt como un contador de rollos adyacentes y se anida otro bucle for para recorrer las 8 direcciones vecinas

-calculamos la posicion del vecino de K con:
    int ni = i + dx[k];
    int nj = j + dy[k];

- Una vez calculada la posicion creamos una condicion para comprobar que no se haya salido de los limites de la matriz:
    if (ni >= 0 && ni < n && nj >= 0 && nj < m)

-Y con if (grid[ni][nj] == '@') cnt++; compruebo si el vecino es un rollo y aumento el contador;

-Siguiendo la condición del enunciado de que el forklift puede acceder al rollo si hay menos de 4 adyacentes:
    if (cnt < 4) {
        result++; \\ sumamos el resulato; resultado= resultado + 1 
    }

\\EJERCICIO 2\\

En este apartado, se nos pide detectar los rollos accesibles y eliminarlos de la matriz, actualizarla y de ese modo volver a comprobarla. Siendo la solucion el numero de veces que se han eliminado rollos de papel hasta no poder quitar más

- Se crea una variable int totalRemoved = 0; para almacenar el resulato 

-Creamos una variable de control 
    bool removedSomething = true;
    indica si en una iteracion se eliminó al menos 1 rollo 
    Por tanto:
     while (removedSomething) :
        removedSomething = false;
        vector<pair<int,int>> toRemove;
    Se asume que no se quita nada hasta demostrar lo contrario y se crea toRemove para guardar las posiciones que se pueden quitar (programación dinámica)

-if (!toRemove.empty()) :
            removedSomething = true;
            totalRemoved += toRemove.size();
    Si el vecto de posiciones con rollo no está vacio, marcamos para seguir en el bucle y sumamos al resultado

-for (auto &p : toRemove) {
                matriz[p.first][p.second] = '.'; // Marcamos como retirado
            }
    Eliminamos. El bucle lo hemos realizado con ayuda externa para tener una primerra toma de contacto con los bucles basados en rango.
    En este caso seria como decir que para cada elemento p de toRemove haga lo de dentro del bucle, cambiar en la posicion indicada de la matriz '@' por '.'.

La forma con la que hemos trabajado más en clase sería la siguiente:

    for (int i = 0; i < toRemove.size(); i++) {
        int fila = toRemove[i].first;
        int columna = toRemove[i].second;
        matriz[fila][columna] = '.';
    }
