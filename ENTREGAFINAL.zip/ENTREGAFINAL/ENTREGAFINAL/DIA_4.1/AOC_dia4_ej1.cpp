#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

int main() {
    ifstream file("input4.txt");
    vector<string> matriz;
    string line;

    while (file >> line) {
        matriz.push_back(line);
    }

    int n = matriz.size();
    int m = matriz[0].size();
    int result = 0;

    int dx[8] = {-1,-1,-1,0,0,1,1,1};
    int dy[8] = {-1,0,1,-1,1,-1,0,1};

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (matriz[i][j] == '@') {
                int cnt = 0;
                for (int k = 0; k < 8; k++) {
                    int ni = i + dx[k];
                    int nj = j + dy[k];
                    if (ni >= 0 && ni < n && nj >= 0 && nj < m) {
                        if (matriz[ni][nj] == '@') {
                            cnt++;
                        }
                    }
                }
                if (cnt < 4) {
                    result++;
                }
            }
        }
    }

    cout << result << endl;
    return 0;
}
