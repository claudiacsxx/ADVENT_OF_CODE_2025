\\POR QUÉ ELEGIMOS ESTE EJERCICIO\\

Este ejercicio se ha elegido porque permite ver cómo un mismo problema puede resolverse de distintas formas y cómo mejorar una solución inicial.
La primera versión usa un enfoque directo y sencillo, fácil de entender pero poco eficiente.
La segunda aplica una reorganización del problema, ordenando y uniendo rangos para evitar repeticiones innecesarias.
Así se aprecia claramente la importancia de pensar el algoritmo antes de programar.


\\EJERCICIO1\\

Nos explicaban que los elfos tenian rangos de comida fresca :3-5= 3,4,5== fresco
Un ingrediente era fresco si estana en uno de los rangos
Por  tanto, oomo objetivo teniamos contar ciantos IDs eran frescos.

De esa manera, la estructura del programa sería: leer los rangos frescos, los IDs, para cada ID comprobar si estaba dentro de rango y contar los frescos

Como eran rangos muy largos había que usar unsigned long long ya que sino, en el resultado nos salía fuera de rango.

/Fucnion1/- convertir a numero
-Primero, creamos la función unsigned long long convertir_a_numero(const string &s), que convierte un string en un numero ignorando cualquier cosa que no sea un digito.
-'n' será la variable donde se vaya construyendo el numero 
- for (char c : s) usamos un bucle que recorre caracter a caracter el string; usando el metodo explicado en el dia4
- if (c >= '0' && c <= '9') : solo coge numeros
- n = n * 10 + (c - '0');: desplaza un numero y añade un nuevo digito: ej: "123"-> 1->12->123

/Funcion2/- leer rangos de frescos

-Lee el archivo línea a línea usando getline,La lectura se detiene cuando encuentra una línea vacía.
-Cada línea tiene el formato a-b. Buscando el '-' para separar los 2 numeros
-Se convierten ambas partes a numeros usando la funcion anterior
-se guarda cada rango en el vector 'rangos'

/Funcion3/-Leer IDs y almacenarlos en un vector

-Lee todas las líneas restantes del archivo.
-Convierte cada línea a número usando la funcion convertir_a_numero.
-Devuelve un vector con todos los IDs 

/Funcion5/-Comprobar si los IDs son frescos (están dentro del rango)

-Si encuentra un rango válido, devuelve true.
-Si no pertenece a ninguno, devuelve false.

\\EJERCICIO2\\

/Struct rango/
-Se sustituye el uso de pair<unsigned long long, unsigned long long> por una estructura propia.
-Esto se hace para hacer el código más legible , ya que se accede a los campos por nombre (inicio, fin) en lugar de first y second.