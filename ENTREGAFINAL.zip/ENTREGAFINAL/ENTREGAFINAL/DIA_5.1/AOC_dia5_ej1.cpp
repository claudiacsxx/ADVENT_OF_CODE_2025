#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

unsigned long long convertir_a_numero(const string &s) {
    unsigned long long n = 0;
    for (char c : s) {
        if (c >= '0' && c <= '9') {
            n = n * 10 + (c - '0');
        }
    }
    return n;
}

vector<pair<unsigned long long, unsigned long long>> leer_rangos(ifstream &archivo) {
    vector<pair<unsigned long long, unsigned long long>> rangos;
    string linea;
    while (getline(archivo, linea) && linea != "") {
        size_t guion = linea.find('-');
        string s1 = linea.substr(0, guion);
        string s2 = linea.substr(guion + 1);

        unsigned long long a = convertir_a_numero(s1);
        unsigned long long b = convertir_a_numero(s2);

        rangos.push_back({a, b});
    }
    return rangos;
}


vector<unsigned long long> leer_ids(ifstream &archivo) {
    vector<unsigned long long> ids;
    string linea;
    while (getline(archivo, linea)) {
        if (linea != "") {
            ids.push_back(convertir_a_numero(linea));
        }
    }
    return ids;
}

bool es_fresco(unsigned long long id, const vector<pair<unsigned long long, unsigned long long>> &rangos) {
    for (auto &r : rangos) {
        if (id >= r.first && id <= r.second) return true;
    }
    return false;
}

int main() {
    ifstream archivo("Input5.txt");
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo." << endl;
        return 1;
    }

    vector<pair<unsigned long long, unsigned long long>> rangos = leer_rangos(archivo);
    vector<unsigned long long> ids = leer_ids(archivo);

    int frescos = 0;
    for (auto id : ids) {
        if (es_fresco(id, rangos)) {
            frescos++;
        }
    }

    cout << "Cantidad de ingredientes frescos: " << frescos << endl;
    return 0;
}
