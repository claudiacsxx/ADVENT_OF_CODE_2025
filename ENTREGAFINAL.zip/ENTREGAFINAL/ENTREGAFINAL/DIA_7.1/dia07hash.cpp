#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <queue>
#include <unordered_set>
using namespace std;

//colas y hash para celdas visitadas
//hash para el par (fila,columna)

struct ParHash {
    size_t operator()(const pair<int,int>& p) const {
        return hash<long long>()(((long long)p.first << 32) ^ (long long)p.second);
    }
};

// función que cuenta cuántas veces se divide el haz
int contar_divisiones(const vector<string>& mapa) {
    int fila_inicio = -1, col_inicio = -1;

    // posición inicial 'S'
    for (int f = 0; f < (int)mapa.size(); f++) {
        for (int c = 0; c < (int)mapa[f].size(); c++) {
            if (mapa[f][c] == 'S') {
                fila_inicio = f;
                col_inicio = c;
                break;
            }
        }
        if (fila_inicio != -1) break;
    }

    // cola para BFS
    queue<pair<int,int>> cola;
    cola.push({fila_inicio + 1, col_inicio}); // el haz empieza debajo de S

    // conjunto hash para no repetir haces en la misma celda
    unordered_set<pair<int,int>, ParHash> visitadas;

    // contador
    int divisiones = 0;

    // recorrido BFS
    while (!cola.empty()) {
        auto [fila, col] = cola.front();
        cola.pop();

        // validamos que esté dentro del mapa
        if (fila < 0 || fila >= (int)mapa.size() || col < 0 || col >= (int)mapa[fila].size())
            continue;

        // si ya hemos procesado este haz en esta celda, lo saltamos
        if (visitadas.count({fila, col})) continue;
        visitadas.insert({fila, col});

        char celda = mapa[fila][col];

        if (celda == '.') {
            // el haz sigue hacia abajo
            cola.push({fila + 1, col});
        }
        else if (celda == '^') {
            divisiones++;

            // creamos dos nuevos haces
            cola.push({fila + 1, col - 1}); // izquierda
            cola.push({fila + 1, col + 1}); // derecha
        }
    }

    return divisiones;
}

int main() {
    // leer fichero
    ifstream archivo("input.txt");
    vector<string> mapa;
    string linea;

    if (!archivo) {
        cerr << "Error: no se pudo abrir el fichero input.txt" << endl;
        return 1;
    }

    // leer cada línea y guardarla en el vector
    while (getline(archivo, linea)) {
        mapa.push_back(linea);
    }

    archivo.close();

    int resultado = contar_divisiones(mapa);
    cout << "El número de divisiones es: " << resultado << endl;

    return 0;
}
