#include <bits/stdc++.h>
using namespace std;

//Serviran para almacenar el camino y optimizar la ruta
unordered_map<string, vector<string>> graph;
unordered_map<string, long long> memo;
unordered_set<string> visiting;

//cuenta los caminos
long long dfs(const string& u) {
    if (u == "out"){//finaliza 
	    return 1;
    }
    if (memo.count(u)){
	    return memo[u];
    }
    if (visiting.count(u)){
	    return 0; // evita ciclos
     }

    visiting.insert(u);
    long long ways = 0;

    for (const string& v : graph[u]) {
        ways += dfs(v);
    }

    visiting.erase(u);
    return memo[u] = ways;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string line;
    while (getline(cin, line)) {
        if (line.empty()) continue;

        auto pos = line.find(':');
        string from = line.substr(0, pos);
        string rest = line.substr(pos + 1);

        stringstream ss(rest);
        string to;
        while (ss >> to) {
            graph[from].push_back(to);
        }
    }

    cout << dfs("you") << "\n";
    return 0;
}

