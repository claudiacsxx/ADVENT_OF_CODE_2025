\\ EJERCICIO 11 – REACTOR \\

- Primero declaramos una estructura para representar el grafo:

    unordered_map<string, vector<string>> graph;

  Donde cada clave es un dispositivo y el vector contiene los dispositivos a los que envía datos.

- Definimos también dos estructuras auxiliares:

    unordered_map<string, long long> memo;
    unordered_set<string> visiting;

  memo se utiliza para guardar el número de caminos ya calculados desde un nodo hasta "out" y
  visiting sirve para evitar bucles infinitos.

-Leemos la entrada línea por línea usando getline, separando las partes
  mediante el carácter ':' y almacenando las conexiones en el grafo.

- Se define una función recursiva dfs(u) que devuelve el número de caminos distintos desde el nodo u hasta "out".

-Si u == "out", se devuelve 1, ya que se ha encontrado un camino válido.

- Si el nodo ya ha sido calculado anteriormente, se devuelve el valor almacenado en memo para evitar cálculos repetidos.

- Al terminar, se elimina el nodo de visiting y se guarda el resultado en memo.

- Se llama a la función dfs comenzando desde el nodo "you".
- El valor que se imprime es el número total de caminos distintos que conducen desde "you" hasta "out".
